var swiper = new Swiper(".bySwiper-1",{
    slidesPerView:1,
    spadeBetween:30,
    loop: true,
    pagination: {
        el:".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl:"swiper-button-next",
        prevtEl:"swiper-button-prev",
    }
})
var swiper = new Swiper(".bySwiper-2",{
    slidesPerView:3,
    spadeBetween:20,
    loop: true,
    loopFillGroupWithBlank:true,
    navigation: {
        nextEl:"swiper-button-next",
        prevtEl:"swiper-button-prev",
    },
    breakpoints : {
        0:{
            slidesPerView:1,
        },
        520:{
            slidesPerView:2,
        },
        520:{
            slidesPerView:3,
        }
    }
});
let tabInputs = document.querySelectorAll(".tabInput");
tabInputs.forEach(function(input){
    input.addEventListener('change',function(){
        let id = input.ariaValueMax;
        let thisSwiper =document.getElementById('swiper'+id);
        thisSwiper.swiper.update();
    })
})