function calcular(){
    //proceso de tranferecia del fotmulario Js
    var n1=document.getElementById("valorc").value;
    var n2=document.getElementById("numc").value;
    var n3=document.getElementById("interes").value;
    //proceso de calcular en Js
    var valorA=parseFloat(n1)*parseFloat(n3);// fx valor $ mes a pagar
    var valorB=(parseFloat(n1)*(1+parseFloat(n2)*parseFloat(n3)));//fx pago total $ credito
    //proceso de tranferencia del Js al formulario
    document.getElementById("valora").value=valorA;
    document.getElementById("valorb").value=valorB.toFixed(0);
}
function limpiar(){
    document.getElementById("valorc").value=" ";//borrar input
    document.getElementById("numc").value=" ";//borrar input
    document.getElementById("interes").value=" ";//borrar input
}